// Voidfall Outpost - traversal-improved sketch.js
// p5.js + p5.play
// Changes: double jump, jump pads, ladders, reduced stamina cost, faster regen, moving platforms

let player, platforms, drones, collectibles, hazards, ladders, jumpPads, movingPlatforms;
let camY = 0;
let worldHeight = 1800;
let score = 0;
let lives = 3;
let gameState = 'play'; // 'play','paused','gameover'
let gravity = 0.75; // slightly reduced gravity for easier traversal
let maxScale = 1.8;
let checkpoint;

function setup() {
  createCanvas(800, 600);
  initGame();
}

function initGame() {
  score = 0;
  lives = 3;
  gameState = 'play';
  camY = 0;

  platforms = new Group();
  drones = new Group();
  collectibles = new Group();
  hazards = new Group();
  ladders = new Group();
  jumpPads = new Group();
  movingPlatforms = new Group();

  // Build deterministic large platform layout (clusters)
  let clusters = [
    {x: 200, y: worldHeight - 120, w: 360},
    {x: 600, y: worldHeight - 260, w: 300},
    {x: 120, y: worldHeight - 420, w: 240},
    {x: 520, y: worldHeight - 620, w: 320},
    {x: 260, y: worldHeight - 820, w: 280},
    {x: 640, y: worldHeight - 980, w: 240},
    {x: 200, y: worldHeight - 1180, w: 360},
    {x: 480, y: worldHeight - 1400, w: 300},
    {x: 320, y: worldHeight - 1620, w: 400}
  ];
  for (let c of clusters) {
    let s = createSprite(c.x, c.y, c.w, 14);
    s.immovable = true;
    s.shapeColor = color(60, 90, 140);
    platforms.add(s);
  }

  // Add some vertical moving platforms to help ascend
  let mv1 = createSprite(360, worldHeight - 520, 120, 12);
  mv1.immovable = true;
  mv1.moveRange = {y1: worldHeight - 520, y2: worldHeight - 700};
  mv1.moveDir = -1;
  mv1.speed = 0.8;
  movingPlatforms.add(mv1);

  let mv2 = createSprite(520, worldHeight - 980, 160, 12);
  mv2.immovable = true;
  mv2.moveRange = {y1: worldHeight - 980, y2: worldHeight - 1100};
  mv2.moveDir = -1;
  mv2.speed = 0.6;
  movingPlatforms.add(mv2);

  // safe zones / checkpoints (use first and middle cluster)
  checkpoint = {x: clusters[0].x, y: clusters[0].y - 40};

  // player
  player = createSprite(checkpoint.x, checkpoint.y - 30, 28, 36);
  player.shapeColor = color(200, 220, 255);
  player.scale = 1.0;
  player.maxStamina = 100;
  player.stamina = player.maxStamina;
  player.onGround = false;
  player.setCollider('rectangle', 0, 0, 28, 36);

  // traversal state
  player.canDoubleJump = true;
  player.isClimbing = false;

  // initial drones (scattered in upper zones)
  spawnDroneWave(6, worldHeight - 900, 400);

  // collectibles: oxygen canisters and upgrade modules
  for (let i = 0; i < 30; i++) {
    let p = random(platforms.toArray());
    let cx = p.position.x + random(-p.width/2 + 12, p.width/2 - 12);
    let cy = p.position.y - 18;
    let type = random() < 0.75 ? 'oxygen' : 'upgrade';
    let col = createSprite(cx, cy, 12, 12);
    col.type = type;
    col.shapeColor = (type === 'oxygen') ? color(0, 200, 255) : color(200, 200, 80);
    collectibles.add(col);
  }

  // hazards: electric vents placed on some platforms
  for (let p of platforms.toArray()) {
    if (random() < 0.25) {
      let h = createSprite(p.position.x + random(-p.width/2 + 20, p.width/2 - 20),
                           p.position.y - 6, 28, 8);
      h.immovable = true;
      h.isVent = true;
      h.active = random() < 0.5;
      h.toggleTimer = millis() + random(400, 1600);
      hazards.add(h);
    }
  }

  // Add ladders near some clusters to allow vertical movement
  let ladder1 = createSprite(260, worldHeight - 200, 12, 120);
  ladder1.immovable = true;
  ladder1.isLadder = true;
  ladders.add(ladder1);

  let ladder2 = createSprite(480, worldHeight - 760, 12, 140);
  ladder2.immovable = true;
  ladder2.isLadder = true;
  ladders.add(ladder2);

  // Add jump pads on some platforms
  for (let i = 0; i < 4; i++) {
    let p = random(platforms.toArray());
    let jp = createSprite(p.position.x + random(-p.width/2 + 20, p.width/2 - 20),
                         p.position.y - 10, 28, 8);
    jp.isJumpPad = true;
    jp.shapeColor = color(120, 255, 180);
    jumpPads.add(jp);
  }
}

function draw() {
  background(8, 12, 22);

  if (gameState === 'paused') {
    updateGameLogic(); // still update minimal logic for visuals
    drawWorld();
    drawHUD();
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(28);
    text('PAUSED', width/2, height/2);
    return;
  }

  if (gameState === 'gameover') {
    drawWorld();
    drawHUD();
    fill(255, 80, 80);
    textAlign(CENTER, CENTER);
    textSize(28);
    text('GAME OVER', width/2, height/2 - 20);
    textSize(16);
    text('Press R to restart', width/2, height/2 + 18);
    return;
  }

  updateGameLogic();
  drawWorld();
  drawHUD();

  if (lives <= 0) gameState = 'gameover';
}

function updateGameLogic() {
  // camera follows player but clamps to world
  camY = constrain(player.position.y - height/2, 0, worldHeight - height);

  // move moving platforms
  movingPlatforms.forEach(function(mp) {
    mp.position.y += mp.moveDir * mp.speed;
    if (mp.position.y < mp.moveRange.y2) mp.moveDir = 1;
    if (mp.position.y > mp.moveRange.y1) mp.moveDir = -1;
  });

  push();
  translate(0, -camY);

  // apply gravity only when not climbing
  if (!player.isClimbing) {
    player.velocity.y += gravity;
  } else {
    player.velocity.y = 0; // hold while climbing
  }

  // controls
  handleControls();

  // collisions with platforms and moving platforms
  player.onGround = false;
  player.collide(platforms, platformLanding);
  player.collide(movingPlatforms, platformLanding);

  // collisions with jump pads
  player.overlap(jumpPads, function(p, jp) {
    // strong upward launch and reset double jump
    p.velocity.y = -18;
    p.canDoubleJump = true;
  });

  // ladders: check overlap and allow climbing
  player.isClimbing = false;
  ladders.forEach(function(l) {
    if (player.overlap(l)) {
      // if player presses up/down, enable climbing mode
      if (keyIsDown(UP_ARROW) || keyIsDown(87) || keyIsDown(DOWN_ARROW) || keyIsDown(83)) {
        player.isClimbing = true;
        // allow vertical movement while climbing
        if (keyIsDown(UP_ARROW) || keyIsDown(87)) {
          player.position.y -= 3.2;
        } else if (keyIsDown(DOWN_ARROW) || keyIsDown(83)) {
          player.position.y += 3.2;
        }
      }
    }
  });

  // stamina regen when grounded or climbing (faster regen)
  if (player.onGround) {
    player.stamina = min(player.maxStamina, player.stamina + (10/60)); // faster regen
  } else if (player.isClimbing) {
    player.stamina = min(player.maxStamina, player.stamina + (6/60));
  }

  // collectibles overlap
  player.overlap(collectibles, function(p, c) {
    if (c.type === 'oxygen') {
      player.stamina = min(player.maxStamina, player.stamina + 30);
      score += 50;
    } else if (c.type === 'upgrade') {
      score += 100;
      p.scale = min(maxScale, p.scale * 1.06);
      p.setCollider('rectangle', 0, 0, 28 * p.scale, 36 * p.scale);
      p.maxStamina = min(160, p.maxStamina + 8);
    }
    c.remove();
  });

  // hazards: vents toggle and hurt player if active
  hazards.forEach(function(h) {
    if (h.isVent) {
      if (millis() > h.toggleTimer) {
        h.active = !h.active;
        h.toggleTimer = millis() + random(900, 2200);
      }
      if (h.active && player.overlap(h)) {
        player.stamina -= 0.6;
        if (player.stamina <= 0) {
          loseLife();
        }
      }
    }
  });

  // drones behavior and collisions
  drones.forEach(function(d) {
    if (!d.targeting && abs(d.position.y - player.position.y) < 420 && abs(d.position.x - player.position.x) < 220) {
      d.targeting = true;
      d.setSpeed(6, atan2(player.position.y - d.position.y, player.position.x - d.position.x) * 180 / PI);
    }
    if (d.targeting) {
      if (abs(d.position.x - player.position.x) > 420 || abs(d.position.y - player.position.y) > 520) {
        d.targeting = false;
        d.setSpeed(d.baseSpeed, d.patrolAngle);
      }
    }
    if (d.overlap(player)) {
      loseLife();
    }
  });

  // falling below world bottom
  if (player.position.y > worldHeight + 80) {
    loseLife();
  }

  // spawn occasional falling debris
  if (random() < 0.006) {
    let x = random(40, width - 40);
    let d = createSprite(x, camY - 40, 18, 18);
    d.shapeColor = color(160, 80, 40);
    d.velocity.y = random(4, 8);
    hazards.add(d);
  }

  // remove offscreen temporary hazards
  hazards.forEach(function(h) {
    if (!h.isVent && h.position.y > worldHeight + 200) h.remove();
  });

  pop();
}

function platformLanding(p, plat) {
  if (p.velocity.y >= 0 && p.position.y < plat.position.y) {
    p.velocity.y = 0;
    p.position.y = plat.position.y - plat.height/2 - (p.height/2) * p.scale + 1;
    p.onGround = true;
    p.canDoubleJump = true; // reset double jump on landing
  }
}

function drawWorld() {
  push();
  translate(0, -camY);

  // background gradient
  for (let y = 0; y < height; y++) {
    let t = map(y, 0, height, 0.05, 0.6);
    stroke(8 * t, 12 * t, 22 * t);
    line(0, camY + y, width, camY + y);
  }

  // draw platforms
  platforms.forEach(function(p) {
    push();
    translate(p.position.x, p.position.y);
    fill(60, 90, 140);
    rectMode(CENTER);
    rect(0, 0, p.width, p.height, 6);
    pop();
  });

  // draw moving platforms
  movingPlatforms.forEach(function(mp) {
    push();
    translate(mp.position.x, mp.position.y);
    fill(100, 140, 180);
    rectMode(CENTER);
    rect(0, 0, mp.width, mp.height, 6);
    pop();
  });

  // draw hazards (vents and debris)
  hazards.forEach(function(h) {
    push();
    translate(h.position.x, h.position.y);
    if (h.isVent) {
      fill(h.active ? color(255, 80, 80) : color(80, 80, 120));
      rectMode(CENTER);
      rect(0, 0, h.width, h.height, 3);
    } else {
      fill(160, 80, 40);
      ellipse(0, 0, h.width, h.height);
    }
    pop();
  });

  // draw ladders
  ladders.forEach(function(l) {
    push();
    translate(l.position.x, l.position.y);
    fill(180, 140, 80);
    rectMode(CENTER);
    rect(0, 0, l.width, l.height, 4);
    pop();
  });

  // draw jump pads
  jumpPads.forEach(function(jp) {
    push();
    translate(jp.position.x, jp.position.y);
    fill(120, 255, 180);
    rectMode(CENTER);
    rect(0, 0, jp.width, jp.height, 4);
    pop();
  });

  // draw collectibles
  collectibles.forEach(function(c) {
    push();
    translate(c.position.x, c.position.y);
    if (c.type === 'oxygen') {
      fill(0, 200, 255);
      ellipse(0, 0, 12, 12);
    } else {
      fill(200, 200, 80);
      rectMode(CENTER);
      rect(0, 0, 12, 12, 3);
    }
    pop();
  });

  // draw drones
  drones.forEach(function(d) {
    push();
    translate(d.position.x, d.position.y);
    fill(200, 80, 80);
    rectMode(CENTER);
    rect(0, 0, d.width, d.height, 4);
    pop();
  });

  // draw player
  push();
  translate(player.position.x, player.position.y);
  scale(player.scale);
  fill(180, 200, 255);
  rectMode(CENTER);
  rect(0, 0, player.width, player.height, 6);
  fill(20, 40, 80);
  ellipse(0, -6, player.width*0.6, player.height*0.5);
  pop();

  pop();
}

function drawHUD() {
  fill(255);
  textSize(14);
  textAlign(LEFT, TOP);
  text('Score: ' + score, 8, 8);
  text('Lives: ' + lives, 8, 26);
  text('Scale: ' + nf(player.scale, 1, 2), 8, 44);

  // stamina bar
  let barW = 180;
  let x = width - barW - 12;
  let y = 12;
  stroke(180);
  noFill();
  rect(x, y, barW, 12);
  noStroke();
  fill(0, 200, 255);
  let pct = constrain(player.stamina / player.maxStamina, 0, 1);
  rect(x, y, barW * pct, 12);
  fill(255);
  textAlign(RIGHT, TOP);
  text('Stamina', width - 12, 8);
}

function handleControls() {
  let move = 0;
  if (keyIsDown(LEFT_ARROW) || keyIsDown(65)) move = -1;
  if (keyIsDown(RIGHT_ARROW) || keyIsDown(68)) move = 1;
  player.velocity.x = move * 5.0; // slightly faster horizontal speed

  // jump consumes less stamina now (12)
  if ((keyIsDown(UP_ARROW) || keyIsDown(87))) {
    // if climbing, handled elsewhere
    if (!player.isClimbing) {
      if (player.onGround && player.stamina >= 12) {
        player.velocity.y = -13;
        player.onGround = false;
        player.stamina -= 12;
        player.canDoubleJump = true;
      } else if (!player.onGround && player.canDoubleJump && player.stamina >= 8) {
        // double jump: smaller cost
        player.velocity.y = -12;
        player.canDoubleJump = false;
        player.stamina -= 8;
      }
    }
  }
}

function spawnDroneWave(count, yBase, spreadX) {
  for (let i = 0; i < count; i++) {
    let x = random(80, width - 80);
    let y = yBase + random(-40, 40);
    let d = createSprite(x, y, 36, 24);
    d.shapeColor = color(200, 80, 80);
    d.baseSpeed = random(1.2, 2.4);
    d.patrolAngle = random([0, 180]); // left or right
    d.setSpeed(d.baseSpeed, d.patrolAngle);
    d.targeting = false;
    drones.add(d);
  }
}

function loseLife() {
  lives--;
  // respawn at checkpoint
  player.position.x = checkpoint.x;
  player.position.y = checkpoint.y - 30;
  player.velocity.x = 0;
  player.velocity.y = 0;
  player.stamina = player.maxStamina * 0.5;
  // shrink slightly as penalty
  player.scale = max(0.9, player.scale * 0.96);
  player.setCollider('rectangle', 0, 0, 28 * player.scale, 36 * player.scale);
  player.canDoubleJump = true;
  player.isClimbing = false;
}

function keyPressed() {
  if (key === 'P' || key === 'p') {
    gameState = (gameState === 'paused') ? 'play' : 'paused';
  }
  if (key === 'R' || key === 'r') {
    initGame();
  }
}
